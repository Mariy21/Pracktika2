﻿
namespace beauty_salon
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.beauty_salonDataSet = new beauty_salon.beauty_salonDataSet();
            this.clearfaceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clear_faceTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.clear_faceTableAdapter();
            this.eyebrowsandeyelashesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.eyebrows_and_eyelashesTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.eyebrows_and_eyelashesTableAdapter();
            this.hairdressersmanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hairdressers_manTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.hairdressers_manTableAdapter();
            this.beautysalonDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hairdresserswomanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hairdressers_womanTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.hairdressers_womanTableAdapter();
            this.manicureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.manicureTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.manicureTableAdapter();
            this.pedicuresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pedicuresTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.pedicuresTableAdapter();
            this.massageBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.massageTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.massageTableAdapter();
            this.nailextensionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nail_extensionsTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.nail_extensionsTableAdapter();
            this.varnishcoatingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.varnish_coatingTableAdapter = new beauty_salon.beauty_salonDataSetTableAdapters.varnish_coatingTableAdapter();
            this.serviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beauty_salonDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clearfaceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eyebrowsandeyelashesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hairdressersmanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beautysalonDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hairdresserswomanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.manicureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pedicuresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.massageBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nailextensionsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.varnishcoatingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 554);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "Вернуться";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1244, 554);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 50);
            this.button2.TabIndex = 2;
            this.button2.Text = "Выход";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1381, 536);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1373, 503);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Чистка лица";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1373, 503);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Брови и ресницы";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1373, 503);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Парихмахерские услуги для мужчин";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1373, 503);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Парихмахерские услуги для женщин";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage5.Controls.Add(this.dataGridView5);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1373, 503);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Маникюр";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage6.Controls.Add(this.dataGridView6);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1373, 503);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Педикюр";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage7.Controls.Add(this.dataGridView7);
            this.tabPage7.Location = new System.Drawing.Point(4, 29);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1373, 503);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Массаж";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage8.Controls.Add(this.dataGridView8);
            this.tabPage8.Location = new System.Drawing.Point(4, 29);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1373, 503);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Наращивание ногтей";
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage9.Controls.Add(this.dataGridView9);
            this.tabPage9.Location = new System.Drawing.Point(4, 29);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1373, 503);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Покрытие лаком";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.clearfaceBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn1,
            this.priceDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.eyebrowsandeyelashesBindingSource;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView2.TabIndex = 1;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn2,
            this.priceDataGridViewTextBoxColumn2});
            this.dataGridView3.DataSource = this.hairdressersmanBindingSource;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(3, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView3.TabIndex = 1;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn3,
            this.priceDataGridViewTextBoxColumn3});
            this.dataGridView4.DataSource = this.hairdresserswomanBindingSource;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView4.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView4.TabIndex = 1;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AllowUserToDeleteRows = false;
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView5.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn4,
            this.priceDataGridViewTextBoxColumn4});
            this.dataGridView5.DataSource = this.manicureBindingSource;
            this.dataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView5.Location = new System.Drawing.Point(3, 3);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView5.TabIndex = 1;
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView6.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn5,
            this.priceDataGridViewTextBoxColumn5});
            this.dataGridView6.DataSource = this.pedicuresBindingSource;
            this.dataGridView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView6.Location = new System.Drawing.Point(3, 3);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView6.TabIndex = 1;
            // 
            // dataGridView7
            // 
            this.dataGridView7.AllowUserToAddRows = false;
            this.dataGridView7.AllowUserToDeleteRows = false;
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView7.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn6,
            this.priceDataGridViewTextBoxColumn6});
            this.dataGridView7.DataSource = this.massageBindingSource;
            this.dataGridView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView7.Location = new System.Drawing.Point(3, 3);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.ReadOnly = true;
            this.dataGridView7.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView7.TabIndex = 1;
            // 
            // dataGridView8
            // 
            this.dataGridView8.AllowUserToAddRows = false;
            this.dataGridView8.AllowUserToDeleteRows = false;
            this.dataGridView8.AutoGenerateColumns = false;
            this.dataGridView8.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView8.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn7,
            this.priceDataGridViewTextBoxColumn7});
            this.dataGridView8.DataSource = this.nailextensionsBindingSource;
            this.dataGridView8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView8.Location = new System.Drawing.Point(3, 3);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.ReadOnly = true;
            this.dataGridView8.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView8.TabIndex = 1;
            // 
            // dataGridView9
            // 
            this.dataGridView9.AllowUserToAddRows = false;
            this.dataGridView9.AllowUserToDeleteRows = false;
            this.dataGridView9.AutoGenerateColumns = false;
            this.dataGridView9.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView9.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceDataGridViewTextBoxColumn8,
            this.priceDataGridViewTextBoxColumn8});
            this.dataGridView9.DataSource = this.varnishcoatingBindingSource;
            this.dataGridView9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView9.Location = new System.Drawing.Point(3, 3);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.ReadOnly = true;
            this.dataGridView9.Size = new System.Drawing.Size(1367, 497);
            this.dataGridView9.TabIndex = 1;
            // 
            // beauty_salonDataSet
            // 
            this.beauty_salonDataSet.DataSetName = "beauty_salonDataSet";
            this.beauty_salonDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clearfaceBindingSource
            // 
            this.clearfaceBindingSource.DataMember = "clear_face";
            this.clearfaceBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // clear_faceTableAdapter
            // 
            this.clear_faceTableAdapter.ClearBeforeFill = true;
            // 
            // eyebrowsandeyelashesBindingSource
            // 
            this.eyebrowsandeyelashesBindingSource.DataMember = "eyebrows_and_eyelashes";
            this.eyebrowsandeyelashesBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // eyebrows_and_eyelashesTableAdapter
            // 
            this.eyebrows_and_eyelashesTableAdapter.ClearBeforeFill = true;
            // 
            // hairdressersmanBindingSource
            // 
            this.hairdressersmanBindingSource.DataMember = "hairdressers_man";
            this.hairdressersmanBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // hairdressers_manTableAdapter
            // 
            this.hairdressers_manTableAdapter.ClearBeforeFill = true;
            // 
            // beautysalonDataSetBindingSource
            // 
            this.beautysalonDataSetBindingSource.DataSource = this.beauty_salonDataSet;
            this.beautysalonDataSetBindingSource.Position = 0;
            // 
            // hairdresserswomanBindingSource
            // 
            this.hairdresserswomanBindingSource.DataMember = "hairdressers_woman";
            this.hairdresserswomanBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // hairdressers_womanTableAdapter
            // 
            this.hairdressers_womanTableAdapter.ClearBeforeFill = true;
            // 
            // manicureBindingSource
            // 
            this.manicureBindingSource.DataMember = "manicure";
            this.manicureBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // manicureTableAdapter
            // 
            this.manicureTableAdapter.ClearBeforeFill = true;
            // 
            // pedicuresBindingSource
            // 
            this.pedicuresBindingSource.DataMember = "pedicures";
            this.pedicuresBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // pedicuresTableAdapter
            // 
            this.pedicuresTableAdapter.ClearBeforeFill = true;
            // 
            // massageBindingSource
            // 
            this.massageBindingSource.DataMember = "massage";
            this.massageBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // massageTableAdapter
            // 
            this.massageTableAdapter.ClearBeforeFill = true;
            // 
            // nailextensionsBindingSource
            // 
            this.nailextensionsBindingSource.DataMember = "nail_extensions";
            this.nailextensionsBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // nail_extensionsTableAdapter
            // 
            this.nail_extensionsTableAdapter.ClearBeforeFill = true;
            // 
            // varnishcoatingBindingSource
            // 
            this.varnishcoatingBindingSource.DataMember = "varnish_coating";
            this.varnishcoatingBindingSource.DataSource = this.beauty_salonDataSet;
            // 
            // varnish_coatingTableAdapter
            // 
            this.varnish_coatingTableAdapter.ClearBeforeFill = true;
            // 
            // serviceDataGridViewTextBoxColumn
            // 
            this.serviceDataGridViewTextBoxColumn.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn.Name = "serviceDataGridViewTextBoxColumn";
            this.serviceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn1
            // 
            this.serviceDataGridViewTextBoxColumn1.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn1.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn1.Name = "serviceDataGridViewTextBoxColumn1";
            this.serviceDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn1
            // 
            this.priceDataGridViewTextBoxColumn1.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn1.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn1.Name = "priceDataGridViewTextBoxColumn1";
            this.priceDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn2
            // 
            this.serviceDataGridViewTextBoxColumn2.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn2.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn2.Name = "serviceDataGridViewTextBoxColumn2";
            this.serviceDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn2
            // 
            this.priceDataGridViewTextBoxColumn2.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn2.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn2.Name = "priceDataGridViewTextBoxColumn2";
            this.priceDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn3
            // 
            this.serviceDataGridViewTextBoxColumn3.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn3.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn3.Name = "serviceDataGridViewTextBoxColumn3";
            this.serviceDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn3
            // 
            this.priceDataGridViewTextBoxColumn3.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn3.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn3.Name = "priceDataGridViewTextBoxColumn3";
            this.priceDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn4
            // 
            this.serviceDataGridViewTextBoxColumn4.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn4.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn4.Name = "serviceDataGridViewTextBoxColumn4";
            this.serviceDataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn4
            // 
            this.priceDataGridViewTextBoxColumn4.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn4.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn4.Name = "priceDataGridViewTextBoxColumn4";
            this.priceDataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn5
            // 
            this.serviceDataGridViewTextBoxColumn5.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn5.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn5.Name = "serviceDataGridViewTextBoxColumn5";
            this.serviceDataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn5
            // 
            this.priceDataGridViewTextBoxColumn5.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn5.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn5.Name = "priceDataGridViewTextBoxColumn5";
            this.priceDataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn6
            // 
            this.serviceDataGridViewTextBoxColumn6.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn6.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn6.Name = "serviceDataGridViewTextBoxColumn6";
            this.serviceDataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn6
            // 
            this.priceDataGridViewTextBoxColumn6.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn6.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn6.Name = "priceDataGridViewTextBoxColumn6";
            this.priceDataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn7
            // 
            this.serviceDataGridViewTextBoxColumn7.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn7.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn7.Name = "serviceDataGridViewTextBoxColumn7";
            this.serviceDataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn7
            // 
            this.priceDataGridViewTextBoxColumn7.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn7.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn7.Name = "priceDataGridViewTextBoxColumn7";
            this.priceDataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // serviceDataGridViewTextBoxColumn8
            // 
            this.serviceDataGridViewTextBoxColumn8.DataPropertyName = "service";
            this.serviceDataGridViewTextBoxColumn8.HeaderText = "Услуга";
            this.serviceDataGridViewTextBoxColumn8.Name = "serviceDataGridViewTextBoxColumn8";
            this.serviceDataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn8
            // 
            this.priceDataGridViewTextBoxColumn8.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn8.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn8.Name = "priceDataGridViewTextBoxColumn8";
            this.priceDataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1400, 616);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form3";
            this.Text = "Каталог";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beauty_salonDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clearfaceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eyebrowsandeyelashesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hairdressersmanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beautysalonDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hairdresserswomanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.manicureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pedicuresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.massageBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nailextensionsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.varnishcoatingBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.DataGridView dataGridView9;
        private beauty_salonDataSet beauty_salonDataSet;
        private System.Windows.Forms.BindingSource clearfaceBindingSource;
        private beauty_salonDataSetTableAdapters.clear_faceTableAdapter clear_faceTableAdapter;
        private System.Windows.Forms.BindingSource eyebrowsandeyelashesBindingSource;
        private beauty_salonDataSetTableAdapters.eyebrows_and_eyelashesTableAdapter eyebrows_and_eyelashesTableAdapter;
        private System.Windows.Forms.BindingSource hairdressersmanBindingSource;
        private beauty_salonDataSetTableAdapters.hairdressers_manTableAdapter hairdressers_manTableAdapter;
        private System.Windows.Forms.BindingSource beautysalonDataSetBindingSource;
        private System.Windows.Forms.BindingSource hairdresserswomanBindingSource;
        private beauty_salonDataSetTableAdapters.hairdressers_womanTableAdapter hairdressers_womanTableAdapter;
        private System.Windows.Forms.BindingSource manicureBindingSource;
        private beauty_salonDataSetTableAdapters.manicureTableAdapter manicureTableAdapter;
        private System.Windows.Forms.BindingSource pedicuresBindingSource;
        private beauty_salonDataSetTableAdapters.pedicuresTableAdapter pedicuresTableAdapter;
        private System.Windows.Forms.BindingSource massageBindingSource;
        private beauty_salonDataSetTableAdapters.massageTableAdapter massageTableAdapter;
        private System.Windows.Forms.BindingSource nailextensionsBindingSource;
        private beauty_salonDataSetTableAdapters.nail_extensionsTableAdapter nail_extensionsTableAdapter;
        private System.Windows.Forms.BindingSource varnishcoatingBindingSource;
        private beauty_salonDataSetTableAdapters.varnish_coatingTableAdapter varnish_coatingTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn8;
    }
}