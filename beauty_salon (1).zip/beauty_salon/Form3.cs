﻿using System;
using System.Windows.Forms;

namespace beauty_salon
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ActiveForm.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                this.varnish_coatingTableAdapter.Fill(this.beauty_salonDataSet.varnish_coating);
                this.nail_extensionsTableAdapter.Fill(this.beauty_salonDataSet.nail_extensions);
                this.massageTableAdapter.Fill(this.beauty_salonDataSet.massage);
                this.pedicuresTableAdapter.Fill(this.beauty_salonDataSet.pedicures);
                this.manicureTableAdapter.Fill(this.beauty_salonDataSet.manicure);
                this.hairdressers_womanTableAdapter.Fill(this.beauty_salonDataSet.hairdressers_woman);
                this.hairdressers_manTableAdapter.Fill(this.beauty_salonDataSet.hairdressers_man);
                this.eyebrows_and_eyelashesTableAdapter.Fill(this.beauty_salonDataSet.eyebrows_and_eyelashes);
                this.clear_faceTableAdapter.Fill(this.beauty_salonDataSet.clear_face);
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка подключения к базе данных. Повторите попытку.");
            }
          
        }
    }
}
